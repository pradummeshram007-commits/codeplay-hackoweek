// StudenTrade Marketplace JavaScript - White & Grey Theme

// Application data with updated item counts
const appData = {
  items: [
    {
      id: 1,
      title: "MacBook Air M1 - Excellent Condition",
      price: "₹45,000",
      originalPrice: "₹92,900",
      seller: "Arjun Mehta",
      rating: "4.9",
      condition: "Excellent",
      location: "Near Campus",
      posted: "2 hours ago",
      image: "laptop",
      category: "electronics"
    },
    {
      id: 2,
      title: "Advanced Calculus Mathematics Textbook",
      price: "₹800",
      originalPrice: "₹2,500",
      seller: "Priya Sharma",
      rating: "4.8",
      condition: "Good",
      location: "Girls Hostel B",
      posted: "5 hours ago",
      image: "book",
      category: "books"
    },
    {
      id: 3,
      title: "Casio FX-991ES Scientific Calculator",
      price: "₹1,200",
      originalPrice: "₹1,800",
      seller: "Rahul Kumar",
      rating: "5.0",
      condition: "Like New",
      location: "Hostel Block A",
      posted: "1 day ago",
      image: "calculator",
      category: "electronics"
    },
    {
      id: 4,
      title: "Gaming Chair - Ergonomic Design",
      price: "₹8,500",
      originalPrice: "₹15,000",
      seller: "Amit Singh",
      rating: "4.7",
      condition: "Good",
      location: "Off Campus",
      posted: "2 days ago",
      image: "chair",
      category: "furniture"
    }
  ],
  categories: [
    { name: "books", displayName: "Books & Study Materials", icon: "📚", count: "147" },
    { name: "electronics", displayName: "Electronics & Gadgets", icon: "💻", count: "126" },
    { name: "furniture", displayName: "Room & Furniture", icon: "🛏️", count: "98" },
    { name: "sports", displayName: "Sports & Recreation", icon: "🏀", count: "84" },
    { name: "creative", displayName: "Creative & Art Supplies", icon: "🎨", count: "67" },
    { name: "services", displayName: "Services & Tutoring", icon: "🎓", count: "132" }
  ]
};

// DOM Elements
const elements = {
  mobileMenuBtn: document.getElementById('mobileMenuBtn'),
  navMenu: document.querySelector('.nav-menu'),
  searchInput: document.querySelector('.search-input'),
  searchBtn: document.querySelector('.search-btn'),
  categoryCards: document.querySelectorAll('.category-card'),
  itemCards: document.querySelectorAll('.item-card'),
  modal: document.getElementById('itemModal'),
  modalClose: document.getElementById('modalClose'),
  modalTitle: document.getElementById('modalTitle'),
  modalPrice: document.getElementById('modalPrice'),
  modalOriginalPrice: document.getElementById('modalOriginalPrice'),
  modalSeller: document.getElementById('modalSeller'),
  modalRating: document.getElementById('modalRating'),
  modalCondition: document.getElementById('modalCondition'),
  modalLocation: document.getElementById('modalLocation'),
  modalPosted: document.getElementById('modalPosted'),
  modalImage: document.getElementById('modalImage')
};

// Utility Functions
const utils = {
  // Smooth scroll to element
  smoothScrollTo: (element) => {
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  },

  // Format search query
  formatSearchQuery: (query) => {
    return query.toLowerCase().trim().replace(/\s+/g, ' ');
  },

  // Debounce function for search
  debounce: (func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  },

  // Get item by ID
  getItemById: (id) => {
    return appData.items.find(item => item.id === parseInt(id));
  },

  // Filter items by category
  filterItemsByCategory: (category) => {
    return appData.items.filter(item => item.category === category);
  },

  // Search items
  searchItems: (query) => {
    const formattedQuery = utils.formatSearchQuery(query);
    if (!formattedQuery) return appData.items;
    
    return appData.items.filter(item => {
      const searchableText = `${item.title} ${item.seller} ${item.category}`.toLowerCase();
      return searchableText.includes(formattedQuery);
    });
  }
};

// Navigation functionality
const navigation = {
  init: () => {
    // Mobile menu toggle
    if (elements.mobileMenuBtn && elements.navMenu) {
      elements.mobileMenuBtn.addEventListener('click', navigation.toggleMobileMenu);
    }

    // Close mobile menu on window resize
    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        elements.navMenu?.classList.remove('mobile-open');
        document.body.classList.remove('mobile-menu-open');
      }
    });

    // Smooth scroll for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', (e) => {
        e.preventDefault();
        const target = document.querySelector(anchor.getAttribute('href'));
        if (target) {
          utils.smoothScrollTo(target);
        }
      });
    });
  },

  toggleMobileMenu: () => {
    elements.navMenu?.classList.toggle('mobile-open');
    document.body.classList.toggle('mobile-menu-open');
    
    // Animate hamburger menu
    elements.mobileMenuBtn?.classList.toggle('active');
  }
};

// Search functionality
const search = {
  init: () => {
    if (elements.searchInput && elements.searchBtn) {
      // Search button click
      elements.searchBtn.addEventListener('click', search.performSearch);
      
      // Enter key search
      elements.searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          search.performSearch();
        }
      });

      // Live search with debounce
      elements.searchInput.addEventListener('input', 
        utils.debounce(search.liveSearch, 300)
      );
    }
  },

  performSearch: () => {
    const query = elements.searchInput?.value || '';
    const results = utils.searchItems(query);
    
    if (query.trim()) {
      search.displaySearchResults(results, query);
      search.trackSearchQuery(query);
    }
  },

  liveSearch: (e) => {
    const query = e.target.value;
    if (query.length > 2) {
      const results = utils.searchItems(query);
      search.showSearchSuggestions(results.slice(0, 5));
    } else {
      search.hideSuggestions();
    }
  },

  displaySearchResults: (results, query) => {
    console.log(`Search results for "${query}":`, results);
    // In a real application, this would update the UI with search results
    // For demo purposes, we'll show an alert with grey styling
    alert(`Found ${results.length} items matching "${query}"`);
  },

  showSearchSuggestions: (suggestions) => {
    // Create or update suggestions dropdown
    let suggestionsEl = document.querySelector('.search-suggestions');
    
    if (!suggestionsEl) {
      suggestionsEl = document.createElement('div');
      suggestionsEl.className = 'search-suggestions';
      elements.searchInput?.parentNode.appendChild(suggestionsEl);
    }

    if (suggestions.length > 0) {
      suggestionsEl.innerHTML = suggestions.map(item => 
        `<div class="suggestion-item" data-item-id="${item.id}">
          <span class="suggestion-title">${item.title}</span>
          <span class="suggestion-price">${item.price}</span>
        </div>`
      ).join('');
      
      suggestionsEl.classList.add('visible');
      
      // Add click handlers for suggestions
      suggestionsEl.querySelectorAll('.suggestion-item').forEach(item => {
        item.addEventListener('click', () => {
          const itemId = item.dataset.itemId;
          modal.showItemModal(itemId);
          search.hideSuggestions();
        });
      });
    } else {
      search.hideSuggestions();
    }
  },

  hideSuggestions: () => {
    const suggestionsEl = document.querySelector('.search-suggestions');
    if (suggestionsEl) {
      suggestionsEl.classList.remove('visible');
      setTimeout(() => {
        suggestionsEl.remove();
      }, 300);
    }
  },

  trackSearchQuery: (query) => {
    // Track popular searches for analytics
    console.log('Search tracked:', query);
  }
};

// Category functionality
const categories = {
  init: () => {
    elements.categoryCards.forEach(card => {
      card.addEventListener('click', categories.handleCategoryClick);
      card.addEventListener('mouseenter', categories.handleCategoryHover);
      card.addEventListener('mouseleave', categories.handleCategoryLeave);
    });
  },

  handleCategoryClick: (e) => {
    const card = e.currentTarget;
    const category = card.dataset.category;
    
    if (category) {
      const filteredItems = utils.filterItemsByCategory(category);
      categories.showCategoryItems(category, filteredItems);
      categories.trackCategoryClick(category);
    }
  },

  handleCategoryHover: (e) => {
    const card = e.currentTarget;
    card.style.transform = 'translateY(-8px) scale(1.02)';
  },

  handleCategoryLeave: (e) => {
    const card = e.currentTarget;
    card.style.transform = 'translateY(-4px) scale(1)';
  },

  showCategoryItems: (category, items) => {
    const categoryInfo = appData.categories.find(cat => cat.name === category);
    console.log(`Showing ${items.length} items in ${categoryInfo?.displayName}:`, items);
    
    // In a real application, this would navigate to category page or filter current view
    alert(`Viewing ${items.length} items in ${categoryInfo?.displayName}`);
  },

  trackCategoryClick: (category) => {
    console.log('Category clicked:', category);
  }
};

// Modal functionality
const modal = {
  init: () => {
    // Item card click handlers
    elements.itemCards.forEach(card => {
      card.addEventListener('click', modal.handleItemCardClick);
    });

    // Modal close handlers
    if (elements.modalClose) {
      elements.modalClose.addEventListener('click', modal.hideModal);
    }

    if (elements.modal) {
      elements.modal.addEventListener('click', (e) => {
        if (e.target === elements.modal) {
          modal.hideModal();
        }
      });
    }

    // ESC key to close modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !elements.modal?.classList.contains('hidden')) {
        modal.hideModal();
      }
    });
  },

  handleItemCardClick: (e) => {
    const card = e.currentTarget;
    const itemId = card.dataset.itemId;
    
    if (itemId) {
      modal.showItemModal(itemId);
    }
  },

  showItemModal: (itemId) => {
    const item = utils.getItemById(itemId);
    
    if (item && elements.modal) {
      modal.populateModal(item);
      elements.modal.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
      
      // Track item view
      modal.trackItemView(itemId);
    }
  },

  populateModal: (item) => {
    // Image placeholder mapping - using grey tones
    const imageMap = {
      laptop: '💻',
      book: '📖',
      calculator: '🧮',
      chair: '🪑'
    };

    // Update modal content
    if (elements.modalTitle) elements.modalTitle.textContent = item.title;
    if (elements.modalPrice) elements.modalPrice.textContent = item.price;
    if (elements.modalOriginalPrice) elements.modalOriginalPrice.textContent = item.originalPrice;
    if (elements.modalSeller) elements.modalSeller.textContent = item.seller;
    if (elements.modalRating) elements.modalRating.textContent = `⭐ ${item.rating}`;
    if (elements.modalCondition) elements.modalCondition.textContent = item.condition;
    if (elements.modalLocation) elements.modalLocation.textContent = item.location;
    if (elements.modalPosted) elements.modalPosted.textContent = item.posted;
    
    if (elements.modalImage) {
      elements.modalImage.textContent = imageMap[item.image] || '📦';
      elements.modalImage.className = `image-placeholder ${item.image}`;
    }
  },

  hideModal: () => {
    if (elements.modal) {
      elements.modal.classList.add('hidden');
      document.body.style.overflow = '';
    }
  },

  trackItemView: (itemId) => {
    console.log('Item viewed:', itemId);
  }
};

// Animations and UI enhancements
const animations = {
  init: () => {
    animations.initScrollAnimations();
    animations.initHoverEffects();
  },

  initScrollAnimations: () => {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-in');
        }
      });
    }, observerOptions);

    // Observe elements for animation
    document.querySelectorAll('.category-card, .item-card, .feature-card, .step-card').forEach(el => {
      observer.observe(el);
    });
  },

  initHoverEffects: () => {
    // Enhanced hover effects for interactive elements with grey theme
    document.querySelectorAll('.btn').forEach(btn => {
      btn.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-1px)';
        this.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
      });
      
      btn.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = '';
      });
    });

    // Card hover effects
    document.querySelectorAll('.category-card, .item-card, .feature-card, .step-card').forEach(card => {
      card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-4px)';
        this.style.boxShadow = '0 8px 25px rgba(0, 0, 0, 0.1)';
      });
      
      card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
        this.style.boxShadow = '';
      });
    });
  }
};

// Performance and utility functions
const performance = {
  init: () => {
    performance.lazyLoadImages();
    performance.preloadCriticalResources();
  },

  lazyLoadImages: () => {
    // Simulate lazy loading for image placeholders
    const imageObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.classList.add('loaded');
          imageObserver.unobserve(img);
        }
      });
    });

    document.querySelectorAll('.image-placeholder').forEach(img => {
      imageObserver.observe(img);
    });
  },

  preloadCriticalResources: () => {
    // Preload critical CSS and fonts
    const criticalResources = [
      // Add any critical resources here
    ];

    criticalResources.forEach(resource => {
      const link = document.createElement('link');
      link.rel = 'preload';
      link.href = resource.href;
      link.as = resource.as;
      document.head.appendChild(link);
    });
  }
};

// Error handling
const errorHandler = {
  init: () => {
    window.addEventListener('error', errorHandler.handleError);
    window.addEventListener('unhandledrejection', errorHandler.handlePromiseRejection);
  },

  handleError: (event) => {
    console.error('Application error:', event.error);
    // In production, send to error tracking service
  },

  handlePromiseRejection: (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    // In production, send to error tracking service
  }
};

// Theme and accessibility enhancements
const theme = {
  init: () => {
    theme.setupAccessibility();
    theme.setupKeyboardNavigation();
  },

  setupAccessibility: () => {
    // Add ARIA labels and roles where needed
    document.querySelectorAll('.category-card').forEach(card => {
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', '0');
      card.setAttribute('aria-label', `Browse ${card.querySelector('.category-title')?.textContent}`);
    });

    document.querySelectorAll('.item-card').forEach(card => {
      card.setAttribute('role', 'button');
      card.setAttribute('tabindex', '0');
      card.setAttribute('aria-label', `View details for ${card.querySelector('.item-title')?.textContent}`);
    });

    // Modal accessibility
    if (elements.modal) {
      elements.modal.setAttribute('role', 'dialog');
      elements.modal.setAttribute('aria-modal', 'true');
      elements.modal.setAttribute('aria-labelledby', 'modalTitle');
    }
  },

  setupKeyboardNavigation: () => {
    // Enable keyboard navigation for cards
    document.querySelectorAll('.category-card').forEach(card => {
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          card.click();
        }
      });
    });

    document.querySelectorAll('.item-card').forEach(card => {
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          card.click();
        }
      });
    });
  }
};

// Application initialization
const app = {
  init: () => {
    // Wait for DOM to be ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', app.start);
    } else {
      app.start();
    }
  },

  start: () => {
    try {
      // Initialize all modules
      navigation.init();
      search.init();
      categories.init();
      modal.init();
      animations.init();
      performance.init();
      errorHandler.init();
      theme.init();

      console.log('StudenTrade Marketplace (White & Grey Theme) initialized successfully');
      
      // Add initial animations
      document.body.classList.add('loaded');
      
      // Log updated item counts
      console.log('Category item counts:', appData.categories.map(cat => `${cat.displayName}: ${cat.count} items`));
      
    } catch (error) {
      console.error('Failed to initialize application:', error);
    }
  }
};

// Additional CSS for animations and mobile menu (injected via JavaScript)
const additionalCSS = `
  .mobile-menu-btn.active span:nth-child(1) {
    transform: rotate(-45deg) translate(-5px, 6px);
  }
  
  .mobile-menu-btn.active span:nth-child(2) {
    opacity: 0;
  }
  
  .mobile-menu-btn.active span:nth-child(3) {
    transform: rotate(45deg) translate(-5px, -6px);
  }
  
  .image-placeholder.loaded {
    animation: imageLoad 0.3s ease-out;
  }
  
  .animate-in {
    animation: slideInUp 0.6s ease-out forwards;
  }
  
  @keyframes slideInUp {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  @keyframes imageLoad {
    from {
      opacity: 0.5;
      transform: scale(0.95);
    }
    to {
      opacity: 1;
      transform: scale(1);
    }
  }
  
  body.loaded {
    animation: fadeIn 0.5s ease-out;
  }
  
  @keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
  }
  
  /* Mobile menu styles */
  @media (max-width: 768px) {
    .nav-menu.mobile-open {
      display: flex;
      position: fixed;
      top: 80px;
      left: 0;
      right: 0;
      background: var(--color-bg-card);
      flex-direction: column;
      padding: var(--space-20);
      box-shadow: var(--shadow-lg);
      border-top: 1px solid var(--color-border);
      z-index: 999;
    }
    
    .nav-menu.mobile-open .nav-link {
      padding: var(--space-12) 0;
      border-bottom: 1px solid var(--color-border);
    }
    
    .nav-menu.mobile-open .nav-cta {
      margin-top: var(--space-16);
      align-self: stretch;
      text-align: center;
    }
    
    body.mobile-menu-open {
      overflow: hidden;
    }
  }
  
  /* Focus styles for accessibility */
  .category-card:focus,
  .item-card:focus {
    outline: 2px solid var(--color-primary);
    outline-offset: 2px;
  }
  
  /* Enhanced button focus */
  .btn:focus-visible {
    outline: 2px solid var(--color-primary);
    outline-offset: 2px;
    box-shadow: 0 0 0 3px rgba(64, 64, 64, 0.2);
  }
`;

// Inject additional CSS
const style = document.createElement('style');
style.textContent = additionalCSS;
document.head.appendChild(style);

// Initialize the application
app.init();